package com.dtstack.jlogstash.jdistributed.gclog;

/**
 * Reason:
 * Date: 2017/1/10
 * Company: www.dtstack.com
 *
 * @ahthor xuchao
 */

public class GCTypeConstant {

    public static final String CMS_LOG_TYPE = "cmsgc";

    public static final String YOUNG_LOG_TYPE = "younggc";

    public static final String GC_BEGIN = "gcbegin";
}
