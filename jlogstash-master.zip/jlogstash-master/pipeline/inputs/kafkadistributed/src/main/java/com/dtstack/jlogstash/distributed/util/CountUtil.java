package com.dtstack.jlogstash.distributed.util;

public class CountUtil {
	
	public static boolean count(int index,int multiples){
		return index%multiples==0;
	}
}
