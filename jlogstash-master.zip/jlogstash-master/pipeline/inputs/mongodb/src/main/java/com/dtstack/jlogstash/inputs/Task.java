package com.dtstack.jlogstash.inputs;

/**
 * 任务接口
 * @author zxb
 * @version 1.0.0
 *          2017年03月22日 15:20
 * @since Jdk1.6
 */
public interface Task {

    public void execute();
}
