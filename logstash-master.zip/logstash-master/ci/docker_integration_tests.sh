#!/bin/bash
ci/docker_run.sh logstash-integration-tests ci/integration_tests.sh $@
