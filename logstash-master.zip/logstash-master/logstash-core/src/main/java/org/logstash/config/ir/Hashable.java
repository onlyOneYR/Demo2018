package org.logstash.config.ir;

public interface Hashable {
    String uniqueHash();
}
