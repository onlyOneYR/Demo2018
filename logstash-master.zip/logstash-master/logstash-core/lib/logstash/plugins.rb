require "logstash/plugins/registry"
require 'logstash/plugins/builtin'