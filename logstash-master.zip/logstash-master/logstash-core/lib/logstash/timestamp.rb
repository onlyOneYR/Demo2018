# The contents of this file have been ported to Java. It is included for for compatibility
# with plugins that directly require "logstash/timestamp".
